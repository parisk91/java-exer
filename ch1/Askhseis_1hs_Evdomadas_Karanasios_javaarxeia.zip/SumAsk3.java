package gr.aueb.cf.ch1;

/**
 *Δηλώνει και προσθέτει 2 ακέραιους
 *εμφανίζοντας κείμενο
 *
 * @author paris
 */

public class SumAsk3 {
    public static void main(String[] args) {
        int num1=19;
        int num2=30;
        int sum=num1+num2;

        System.out.printf("Το αποτέλεσμα %d και %d της πρόσθεσης είναι ίσο με %d", num1, num2, sum);


    }
}
