package gr.aueb.cf.ch15;

public class PointUtil {

    public static double distanceFromOrigin(Point point) {
        double  distance = 0.0;
        distance = point.getDistanceFromOrigin();
        return distance;
    }

}