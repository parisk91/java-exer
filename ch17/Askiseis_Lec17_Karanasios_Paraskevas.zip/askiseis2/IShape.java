package gr.aueb.cf.ch17.askiseis2;

public interface IShape {

    long getId();

}
