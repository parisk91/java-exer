package gr.aueb.cf.ch17.askiseis2;

public interface ITwoDimensional {

    public double getArea();
    public double getCircumference();
}
