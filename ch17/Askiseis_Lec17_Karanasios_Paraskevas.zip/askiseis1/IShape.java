package gr.aueb.cf.ch17.askiseis1;

public interface IShape {
    public void getId();
}
