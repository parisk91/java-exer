package gr.aueb.cf.ch16.askiseis1;

public interface IShape {
    public void getId();
}
