package gr.aueb.cf.ch16.askiseis1;

public abstract class AbstractShape implements IShape{
    private long id;

    @Override
    public void getId() {

    }
}
