package gr.aueb.cf.ch16.askiseis1;

public class Line extends AbstractShape{

    private double length;
}
