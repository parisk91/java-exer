package gr.aueb.cf.ch16.askiseis1;

public interface ITwoDimensional {
    double getArea();
}
