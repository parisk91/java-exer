package gr.aueb.cf.ch16.askiseis2;

public interface ITwoDimensional {

    public double getArea();
    public double getCircumference();
}
