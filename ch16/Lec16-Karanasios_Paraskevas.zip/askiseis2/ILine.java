package gr.aueb.cf.ch16.askiseis2;

public interface ILine extends IShape{
    @Override
    long getId();
}
