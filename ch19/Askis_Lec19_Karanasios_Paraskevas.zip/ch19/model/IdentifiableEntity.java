package gr.aueb.cf.ch19.model;

public interface IdentifiableEntity {

    Long getId();
}
